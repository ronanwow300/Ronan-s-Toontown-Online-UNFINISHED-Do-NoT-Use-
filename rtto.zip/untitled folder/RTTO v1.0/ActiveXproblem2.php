<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html><head><title>Problem Downloading Toontown Installer</title>
<meta name="robots" content="follow,noindex">
<meta http-equiv="imagetoolbar" content="no">
    <script type="text/javascript">
    <!--
        
    
    
    var logs=new Array();
    var logsi=0;

    function logit()
    {
        
        var a ="";

        for (var i=0; i<arguments.length; i++) {
          if (i%2 == 0) {
            // Name
            a+=escape(arguments[i]);
            a+= "=";
          } else {
            // Value
            a+=escape(arguments[i]);
            a+=((i+1)!=arguments.length)?"&":"";
          }

        }

      var s="./shared/www/collect.php?deployment=US&rand="+Math.random()+"&"+a;
      var lognum = ++logsi;
      logs[lognum%9]=new Image();
      logs[lognum%9].src=s;
    }
        //-->
    </script>

  <script type="text/javascript">
<!--

function popWin (name) {

  logit("NAME", "CLICKTHRU-POPUP", "t", name);
  
  if (name == "WHATISGAMECARD") {
    window.open("./popups/gameCardWhatIsMain.php","whatisgamecard","width=700,height=450,resizable=0");
  } else if (name == "GAMECARDHELP") {
    window.open("./popups/gameCardHelpFrameset.html","gamecardhelp","width=518,height=420,resizable=1");
  } else if (name == "WHATISCOGBUCKS") {
    window.open("./popups/cogBucksWhatIsMain.php","whatiscogbucks","width=700,height=450,resizable=0");
  } else if (name == "WHATISGUESTPASS") {
    window.open("./popups/guestPassWhatIsMain.php","whatisguestpass","width=700,height=450,resizable=0");
  } else if (name == "WHATISSONYCDROM") {
    window.open("./popups/sonyCDWhatIsMain.php","whatissonycdrom","width=710,height=450,resizable=0");
  } else if (name == "FINDGAMECARD") {
    window.open("http://www.usa.att.com/webcents/disneystoontown_home.jsp","findgamecard","resizable=1,scrollbars=1,menubar=1,toolbar=1,location=1,status=1,directories=1");
  }


}

function popNews(url) {
  _news_popup = window.open("/frontPageArticle.php?articleID=" + url, "news","width=470,height=400,resizable=0,scrollbars=1");
  _news_popup.focus();
}

//-->
</script>

  <script type="text/javascript" src="http://a.disney.go.com/detect/scripts/master_flash_writer.js"></script>
    <script type="text/javascript">
        <!--
    headerPromoRight_Reg=new Image();
    headerPromoRight_Reg.src="/shared/images/topnav/hdrPromoRight_reg.gif";
    headerPromoRight_Over=new Image();
    headerPromoRight_Over.src="/shared/images/topnav/hdrPromoRight_over.gif";
    headerSubscribeRight_Reg=new Image();
    headerSubscribeRight_Reg.src="/shared/images/topnav/hdrSubscribeRight_reg.gif";
    headerSubscribeRight_Over=new Image();
    headerSubscribeRight_Over.src="/shared/images/topnav/hdrSubscribeRight_over.gif";
    headerTrialRight_Reg=new Image();
    headerTrialRight_Reg.src="/shared/images/topnav/hdrFreeTrial_reg.gif";
    headerTrialRight_Over=new Image();
    headerTrialRight_Over.src="/shared/images/topnav/hdrFreeTrial_over.gif";
    headerDownloadRight_Reg=new Image();
    headerDownloadRight_Reg.src="/shared/images/topnav/hdrDownloadRight_reg.gif";
    headerDownloadRight_Over=new Image();
    headerDownloadRight_Over.src="/shared/images/topnav/hdrDownloadRight_over.gif";

    function img_over(imgName){
      imgOn=eval(imgName + "_Over.src");
      document [imgName].src=imgOn;
    }
    function img_reg(imgName){
      imgOn=eval(imgName + "_Reg.src");
      document [imgName].src=imgOn;
    }
    -->
    </script>
    </head>
<body id='us' onLoad="javascript:window_onload(); " onUnload=""  bgcolor="#ff6633" style="margin-top:0;margin-bottom:0;" >

    <table width="770" cellspacing="0" cellpadding="0" border="0" align="center">
      <tr bgcolor="#FFAA88" height="50">
        <td colspan="2"><font face="arial,helvetica" size="3"><center><b>This is the Toontown Test Server.</b><br>
        If you are here by mistake, please <A href="http://play.toontown.com/">Play Toontown Here</a> instead.</font></td>
      </tr>
    </table>


    


  
    <table width="770" cellspacing="0" cellpadding="0" border="0" bgcolor="#ffffff" align="center">
      <tr>
        <td colspan="5">
        <!--Begin Header-->
        <table cellspacing="0" cellpadding="0" border="0" align="center">
          <tr>
            <td><a href='./store/index.php'><img src="/shared/images/topnav/customTshirtPromo.gif" width="133" height="109" alt="Custom T-Shirt Promo" border="0"></a><br></td>
                      <td><a href="./news.php"><img src="/shared/images/topnav/hdrCenterLogo.gif" width="516" height="109" alt="Disney's Toontown Online" border="0"></a></td>

                          <td><a href="https://account.test.toontown.com/webPlay.php"><img name="headerPromoRight" src="/shared/images/topnav/hdrPromoRight_reg.gif" width="121" height="109" alt="Play Now!" border="0" onMouseover="img_over('headerPromoRight');" onMouseout="img_reg('headerPromoRight');"></a></td>

            
          
          </tr>
          <tr>
            <td colspan="3"><img src="/shared/images/topnav/hdrSepStrip.gif" width="770" height="23" alt="Are You Toon Enough?" border="0"></td>
          </tr>
        </table>
        <!--End Header-->
        </td>
      </tr>
      <tr>
          <td width="154" valign="top" align="center">
          <script type="text/javascript">
          <!--
            flashObj=new FlashObj(
              "/shared/images/flash/leftnav.swf?exitSignUpUrl=./news.php&amp;navXML=./shared/include/xml/nav.xml?v=4b&amp;username=&amp;baseplayurl=./&amp;baseaccounturl=https://account.test.toontown.com/&amp;exitSignUpHbx=leftnav_exitsignup&amp;baseHbx=&amp;memberServicesUrl=MEMBERSERVICES&amp;emailPrefUrl=./unavailableOnTestServer.php&amp;changePwdUrl=./unavailableOnTestServer.php&amp;memberInfoUrl=./unavailableOnTestServer.php&amp;billingInfoUrl=./unavailableOnTestServer.php&amp;", // swf
              "154", //width
              "1050", // height
              "#ffffff", // background
              "", // version
              "tt_nav", // id
              "menu=false"
              );
            flashObj.render();
          -->
          </script>
        </td>

     <td width="14" style="border-left:1px solid #000000;" rowspan="2">&nbsp;</td>
     <td width="434" rowspan="1" valign="top">
     <!--End Mid Content-->

<SCRIPT LANGUAGE=javascript>
<!--
function window_onload() {
  var agt=navigator.userAgent.toLowerCase();
  var is_winnt = ((agt.indexOf("winnt")!=-1) || (agt.indexOf("windows nt")!=-1));
  if(is_winnt) {
      //NTadminMsg.style.display = "inline";
  }
}
//-->
</SCRIPT>

<table cellspacing="0" cellpadding="0" border="0" width="434">
<!--
  <tr height="40" valign="bottom">
    <td align="right"><font face="arial,helvetica" size="1">
    <a href="javascript:window.print();">
    <img src="/shared/images/buttons/print_red.gif" width=" 100" height="23" border="0" alt="Print page">
    </a>
    </font></td>
  </tr>
  -->  

   <tr height="60">
    <td align="center"><br><font face="arial,helvetica" size="4" color="#FF0000"><b>Toontown Installation</b></font></td>
  </tr>


  <tr>
    <td>
      <font face="arial,helvetica" size="2">
        Internet Explorer was unable to download Toontown Installer version (1,0,19,5).  To continue, a new Toontown Installer ActiveX control must be allowed to download and run.<br><br>
      
      If you were not prompted to download the control before seeing this page, please try one or more of the following to resolve your issue:<br><br>
      </font>     
    </td>
  </tr>
  
  <tr>
    <td>
      <table cellspacing="0" cellpadding="0" border="0" width="100%">
        <tr>  
          <td width="5%">
            <font face="arial,helvetica" size="2">
              1.            
            </font>
          </td>
          <td width="*">
            <font face="arial,helvetica" size="2">
               <b>On Windows XP Service Pack 2</b>            
            </font>
          </td>
        </tr>     
        <tr>  
          <td width="5%">
          </td>
          <td width="*">
            <font face="arial,helvetica" size="2">
              <a href="ActiveXproblemSP2.php">Click here</a> for more information on installing the Toontown ActiveX control with Windows XP Service Pack 2.<br><br>           
            </font>
          </td>
        </tr>        
      </table>       
    </td>
  </tr>
  
  <tr>
    <td>
      <table cellspacing="0" cellpadding="0" border="0" width="100%">
        <tr>  
          <td width="5%">
            <font face="arial,helvetica" size="2">
              2.            
            </font>
          </td>
          <td width="*">
            <font face="arial,helvetica" size="2">
              <b>On Windows XP (without Service Pack 2) or Windows 2000</b>
            </font>
          </td>
        </tr>     
        <tr>  
          <td width="5%">
          </td>
          <td width="*">
            <font face="arial,helvetica" size="2">
              Toontown must be installed or updated by a machine administrator.  Once an account with administrator privileges has successfully started the game, limited-access accounts should be able to play.  On Windows XP, you can determine if your account has administrator privileges by clicking<br>
              <b>Start Menu->Settings->Control Panel->User Accounts</b><br>
          and seeing if your account name is listed as <i>Computer Administrator</i> or <i>Limited Account</i>.<br><br>
            </font>
          </td>
        </tr>        
      </table>       
    </td>
  </tr>
  
  <tr>
    <td>
      <table cellspacing="0" cellpadding="0" border="0" width="100%">
        <tr>  
          <td width="5%">
            <font face="arial,helvetica" size="2">
              3.            
            </font>
          </td>
          <td width="*">
            <font face="arial,helvetica" size="2">
              <b>Internet Security Settings Problem</b>
           </font>
          </td>
        </tr>     
        <tr>  
          <td width="5%">
          </td>
          <td width="*">
            <font face="arial,helvetica" size="2">
              The Browser Security Zone labeled <i>Internet</i> must allow browser "cookies", so it cannot be set to the <i>High</i> level.  To fix this:<br><br>
              1) Click <b>Start Menu->Settings->Control Panel->Internet Options</b><br>
              2) Click the <b>Security</b> tab.<br>
              3) Make sure the <i>Internet</i> icon is highlighted, and click the <b>Custom<br>
               &nbsp;&nbsp;&nbsp;&nbsp;Level</b> button.<br>
              4) Under <b>Reset custom settings</b>, select <i>Medium</i> and click <b>Reset</b>.<br><br>
                Setting the security level to <i>Medium</i> will let the browser prompt you with 'Do you want to install and run the Toontown Installer?'.  Click yes to continue Toontown installation.<br><br>

              If you do not wish to change the overall <i>Internet</i>-zone browser security setting, the specific Internet Explorer security options that must be enabled to install Toontown are:<br><br>
           </font>
          </td>
        </tr>        
      </table>       
    </td>
  </tr>

  <tr>
    <td>
      <table cellspacing="0" cellpadding="0" border="0" width="100%">
        <tr>  
          <td width="5%">
          </td>
          <td colspan="2" width="95%" align="center">
            <font face="arial,helvetica" size="3">
              <b><u>IE 6.0</u></b>
           </font>
          </td>
       </tr>     
     </table>       
    </td>
  </tr>
  
  <tr>
    <td>
      <table cellspacing="0" cellpadding="0" border="0" width="100%">
        <tr>  
          <td width="5%">
          </td>
          <td width="70%">
            <font face="arial,helvetica" size="2">
              Download signed ActiveX controls            
            </font>
          </td>
          <td width="*" align="left">
            <font face="arial,helvetica" size="2">
              <b>Enable</b> or <b>Prompt</b>           
            </font>
          </td>
      </tr>     
     </table>       
    </td>
  </tr>

  <tr>
    <td>
      <table cellspacing="0" cellpadding="0" border="0" width="100%">
        <tr>  
          <td width="5%">
          </td>
          <td width="70%">
            <font face="arial,helvetica" size="2">
              Run ActiveX controls and plugins           
            </font>
          </td>
          <td width="*" align="left">
            <font face="arial,helvetica" size="2">
              <b>Enable</b>           
            </font>
          </td>
      </tr>     
     </table>       
    </td>
  </tr>
  
  <tr>
    <td>
      <table cellspacing="0" cellpadding="0" border="0" width="100%">
        <tr>  
          <td width="5%">
          </td>
          <td width="70%">
            <font face="arial,helvetica" size="2">
              Script ActiveX controls marked safe for scripting
            </font>
          </td>
          <td width="*" align="left">
            <font face="arial,helvetica" size="2">
              <b>Enable</b>           
            </font>
          </td>
      </tr>     
     </table>       
    </td>
  </tr>
  
  <tr>
    <td>
      <table cellspacing="0" cellpadding="0" border="0" width="100%">
        <tr>  
          <td width="5%">
          </td>
          <td width="70%">
            <font face="arial,helvetica" size="2">
              File download
            </font>
          </td>
          <td width="*" align="left">
            <font face="arial,helvetica" size="2">
              <b>Enable</b>           
            </font>
          </td>
      </tr>     
     </table>       
    </td>
  </tr>
  
  <tr>
    <td>
      <table cellspacing="0" cellpadding="0" border="0" width="100%">
        <tr>  
          <td width="5%">
          </td>
          <td width="70%">
            <font face="arial,helvetica" size="2">
              Active Scripting  
            </font>
          </td>
          <td width="*" align="left">
            <font face="arial,helvetica" size="2">
              <b>Enable</b>           
            </font>
          </td>
      </tr>     
     </table>       
    </td>
  </tr>
 
  <tr height="20">
    <td>
    </td>
  </tr>
  
  <tr>
    <td>
      <table cellspacing="0" cellpadding="0" border="0" width="100%">
        <tr>  
          <td width="5%">
          </td>
          <td colspan="2" width="95%" align="center">
            <font face="arial,helvetica" size="3">
              <b><u>IE 4.0/5.0</u></b>
           </font>
          </td>
       </tr>     
     </table>       
    </td>
  </tr>
  
  <tr>
    <td>
      <table cellspacing="0" cellpadding="0" border="0" width="100%">
        <tr>  
          <td width="5%">
          </td>
          <td width="70%">
            <font face="arial,helvetica" size="2">
              Download signed ActiveX controls            
            </font>
          </td>
          <td width="*" align="left">
            <font face="arial,helvetica" size="2">
              <b>Enable</b> or <b>Prompt</b>           
            </font>
          </td>
      </tr>     
     </table>       
    </td>
  </tr>
  
  <tr>
    <td>
      <table cellspacing="0" cellpadding="0" border="0" width="100%">
        <tr>  
          <td width="5%">
          </td>
          <td width="70%">
            <font face="arial,helvetica" size="2">
              Run ActiveX controls          
            </font>
          </td>
          <td width="*" align="left">
            <font face="arial,helvetica" size="2">
               <b>Enable</b> or <b>Prompt</b>
            </font>
          </td>
      </tr>     
     </table>       
    </td>
  </tr>
  
  <tr>
    <td>
      <table cellspacing="0" cellpadding="0" border="0" width="100%">
        <tr>  
          <td width="5%">
          </td>
          <td width="70%">
            <font face="arial,helvetica" size="2">
              Script ActiveX controls           
            </font>
          </td>
          <td width="*" align="left">
            <font face="arial,helvetica" size="2">
              <b>Enable</b>           
            </font>
          </td>
      </tr>     
     </table>       
    </td>
  </tr>
  
  <tr>
    <td>
      <table cellspacing="0" cellpadding="0" border="0" width="100%">
        <tr>  
          <td width="5%">
          </td>
          <td width="70%">
            <font face="arial,helvetica" size="2">
              File download
            </font>
          </td>
          <td width="*" align="left">
            <font face="arial,helvetica" size="2">
              <b>Enable</b>           
            </font>
          </td>
      </tr>     
     </table>       
    </td>
  </tr>
  
  <tr>
    <td>
      <table cellspacing="0" cellpadding="0" border="0" width="100%">
        <tr>  
          <td width="5%">
          </td>
          <td width="70%">
            <font face="arial,helvetica" size="2">
              Allow cookies to be stored
            </font>
          </td>
          <td width="*" align="left">
            <font face="arial,helvetica" size="2">
              <b>Enable</b>           
            </font>
          </td>
      </tr>     
     </table>       
    </td>
  </tr>
  
  <tr>
    <td>
      <table cellspacing="0" cellpadding="0" border="0" width="100%">
        <tr>  
          <td width="5%">
          </td>
          <td width="70%">
            <font face="arial,helvetica" size="2">
              Allow per-session cookies
            </font>
          </td>
          <td width="*" align="left">
            <font face="arial,helvetica" size="2">
              <b>Enable</b>           
            </font>
          </td>
      </tr>     
     </table>       
    </td>
  </tr>

</table>


    <!--End Mid Content-->
        </td>
        <td width="14" style="border-right:1px solid #000000;" rowspan="2">&nbsp;</td>
     <td width="154" rowspan="1" valign="top" align="center">
       <img src="/shared/images/rightnav/tt_tab_toonsworldunite.gif" width="154" height="15" alt="Toons of the World Unite!">
       <br>
       <script type="text/javascript">
       <!--
         flashObj=new FlashObj(
           "/shared/images/flash/topToons.swf?theDate=09212010&amp;topToonURL=/shared/images/dynamic/topToonImages/2010_09_21_small/&amp;imageBaseURL=/shared/images&amp;moreTopToonsURL=./topToons.php&amp;imageFileURL=/dynamic/topToonImages/2010_09_21_small/", // swf
           "154", //width
           "330", // height
           "#ffffff", // background
           "", // version
           "top_toons", // id
           "menu=false"
           );
         flashObj.render();
       -->
       </script>
       <br>
       <img src="/shared/images/castyourvote.gif" width="154" height="65" alt="Cast your VOTE!">
       <br>
       <script type="text/javascript">
       <!--
         flashObj=new FlashObj(
           "/shared/images/flash/poll_small.swf?basePollPath=/shared/www/&amp;pollId=444&amp;alreadyAnswered=false&amp;pollType=undefined", // swf
           "154", //width
           "208", // height
           "#ffffff", // background
           "", // version
           "poll_small", // id
           "menu=false"
           );
         flashObj.render();
       -->
       </script>
       <br>

      </td>
    </tr>
    <tr><td colspan="5"><img src="/shared/images/lines.jpg" width="770" height="12" alt="" border="0"></td></tr>
      <tr><td colspan="5" align="center">

<script type="text/javascript">
<!--
var legalFooterColor="#0000ff";
var legalFtrLine1="<div style='font-weight: bold;'>Disney's Toontown Online</div>";
var legalFtrOpts=["Member/Guest Services","./unavailableOnTestServer.php","Help","./faq/","Contact Us","http://apps.disneyblast.go.com/cgi-bin/mail/generic_mail.cgi?template=toontown/toonhelp.tpl"]
var legalFtrCpyRgt='<div style="font: verdana, arial, helvetica, sans-serif 1pt; color:#000000;"><a href="./memberAgreement.php">Member Agreements</a>&nbsp;|&nbsp;<a href="http://home.disney.go.com/guestservices/netiquette">House Rules</a><br>&copy; Disney. All rights reserved.</div>';
-->
</script>
<div id="tt_footer" align="center">
  <script type="text/javascript" src="http://a.disney.go.com/globalmedia/legal_footer/legalfooter.js"></script>
</div>
      </td></tr>
    </table>
  <!-- BEGIN DOL Web Analytics 1.0 -->
  <script type="text/javascript" src="http://aglobal.go.com/stat/dolWebAnalytics.js"></script>
  <script type="text/javascript">
    <!--
    cto=new CTO();
    cto.h.mlc='/Toontown/US/Beta/PROSPECT/';
    cto.h.pageName='_ActiveXproblem2';
    cto.registrationStatus='prospect';
    cto.genre='us';//country
    cto.account='toontown';
    cto.category='dgame';
    cto.site='tnt_beta';
    cto.siteSection='website';
    cto.pageName='activexproblem2';
    cto.contentType='regular';
    cto.property='tnt';
    cto.track();
    -->
  </script>
  <!-- END DOL Web Analytics 1.0 -->
</body></html>

