<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Toontown Awards</title>
<meta name="robots" content="follow,noindex">
<meta http-equiv="imagetoolbar" content="no">
<link type="text/css" rel="stylesheet" href="./shared/include/css/global.css">
    <!--WEBSIDESTORY CODE HBX(Global)(Universal)-->
    <!--COPYRIGHT 1997-2004 WEBSIDESTORY,INC. ALL RIGHTS RESERVED. U.S.PATENT No. 6,393,479B1. MORE INFO:http://websidestory.com/privacy-->
    <script src = "http://hb.disney.go.com/stat/hitboxcode.js" type="text/javascript"></script>
      <script type="text/javascript">
      hitbox = new HB_CreateObject("/toontown/US/PROSPECT/NEWS");
      hitbox.HB_PlaceAccount("DM53030620EW42EN3","DM510612FMNS38EN3","DM51030813MR38EN3","DM5103083LCA38EN3");
      hitbox.HB_PlaceName("_awards_index");
    
            
    </script>
   
      

      <script type="text/javascript"> 
        hitbox.HB_render();
      </script>       
    
    <!--END WEBSIDESTORY CODE-->
      <script type="text/javascript">
    <!--
        
    
    
    var logs=new Array();
    var logsi=0;

    function logit()
    {
        
        var a ="";

        for (var i=0; i<arguments.length; i++) {
          if (i%2 == 0) {
            // Name
            a+=escape(arguments[i]);
            a+= "=";
          } else {
            // Value
            a+=escape(arguments[i]);
            a+=((i+1)!=arguments.length)?"&":"";
          }

        }

      var s="./shared/www/collect.php?deployment=US&rand="+Math.random()+"&"+a;
      var lognum = ++logsi;
      logs[lognum%9]=new Image();
      logs[lognum%9].src=s;
    }
        //-->
    </script>

  <script type="text/javascript">
<!--

function popWin (name) {

  logit("NAME", "CLICKTHRU-POPUP", "t", name);
  
  if (name == "WHATISGAMECARD") {
    window.open("./popups/gameCardWhatIsMain.php","whatisgamecard","width=700,height=450,resizable=0");
  } else if (name == "GAMECARDHELP") {
    window.open("./popups/gameCardHelpFrameset.html","gamecardhelp","width=518,height=420,resizable=1");
  } else if (name == "WHATISCOGBUCKS") {
    window.open("./popups/cogBucksWhatIsMain.php","whatiscogbucks","width=700,height=450,resizable=0");
  } else if (name == "WHATISGUESTPASS") {
    window.open("./popups/guestPassWhatIsMain.php","whatisguestpass","width=700,height=450,resizable=0");
  } else if (name == "WHATISSONYCDROM") {
    window.open("./popups/sonyCDWhatIsMain.php","whatissonycdrom","width=710,height=450,resizable=0");
  } else if (name == "FINDGAMECARD") {
    window.open("http://www.usa.att.com/webcents/disneystoontown_home.jsp","findgamecard","resizable=1,scrollbars=1,menubar=1,toolbar=1,location=1,status=1,directories=1");
  }


}

function popNews(url) {
  _news_popup = window.open("/frontPageArticle.php?articleID=" + url, "news","width=470,height=400,resizable=0,scrollbars=1");
  _news_popup.focus();
}

//-->
</script>

  <!--Detection Version 2.1.0-->
<script src = "http://disney.go.com/detect/scripts/master_flash_writer.js" type="text/javascript"></script>
<!--End Detection-->
    <script type="text/javascript">

                headerPromoRight_Reg = new Image();
        headerPromoRight_Reg.src = "/shared/images/topnav/hdrPromoRight_reg.gif";

        headerPromoRight_Over = new Image();
        headerPromoRight_Over.src = "/shared/images/topnav/hdrPromoRight_over.gif";

        headerSubscribeRight_Reg = new Image();
        headerSubscribeRight_Reg.src = "/shared/images/topnav/hdrSubscribeRight_reg.gif";

        headerSubscribeRight_Over = new Image();
        headerSubscribeRight_Over.src = "/shared/images/topnav/hdrSubscribeRight_over.gif";

        headerTrialRight_Reg = new Image();
        headerTrialRight_Reg.src = "/shared/images/topnav/hdrFreeTrial_reg.gif";

        headerTrialRight_Over = new Image();
        headerTrialRight_Over.src = "/shared/images/topnav/hdrFreeTrial_over.gif";

        headerDownloadRight_Reg = new Image();
        headerDownloadRight_Reg.src = "/shared/images/topnav/hdrDownloadRight_reg.gif";

        headerDownloadRight_Over = new Image();
        headerDownloadRight_Over.src = "/shared/images/topnav/hdrDownloadRight_over.gif";


        function img_over(imgName) {
          imgOn = eval(imgName + "_Over.src");
          document [imgName].src = imgOn;
        }

        function img_reg(imgName) {
          imgOn = eval(imgName + "_Reg.src");
          document [imgName].src = imgOn;
        }


    </script>

    </head>
<body id='us' onload="" onunload=""  bgcolor="#ff6633" style="margin-top:0;margin-bottom:0;" >

    <table width="770" cellspacing="0" cellpadding="0" border="0" align="center">
      <tr bgcolor="#FFAA88" height="50">
        <td colspan="2"><font face="arial,helvetica" size="3"><center><b>This is the Toontown Test Server.</b><br>
        If you are here by mistake, please <A href="http://play.toontown.com/">Play Toontown Here</a> instead.</font></td>
      </tr>
    </table>


    


  
    <table width="770" cellspacing="0" cellpadding="0" border="0" bgcolor="#ffffff" align="center">
      <tr>

          <td colspan="5">
    <!-- START HEADER -->
        <table cellspacing="0" cellpadding="0" border="0" align="center">
          <tr>
            <td><a href='./store/index.php'><img src="/shared/images/topnav/customTshirtPromo.gif" width="133" height="109" alt="Custom T-Shirt Promo" border="0"></a><br></td>
                      <td><a href="./news.php"><img src="/shared/images/topnav/hdrCenterLogo.gif" width="516" height="109" alt="Disney's Toontown Online" border="0"></a></td>

                          <td><a href="https://account.test.toontown.com/webWelcome.php"><img name="headerTrialRight" src="/shared/images/topnav/hdrFreeTrial_reg.gif" width="121" height="109" alt="Free Trial!" border="0" onMouseover = "img_over('headerTrialRight');" onMouseout = "img_reg('headerTrialRight');"></a></td>

            
          
          </tr>
          <tr>
            <td colspan="3"><img src="/shared/images/topnav/hdrSepStrip.gif" width="770" height="23" alt="Are You Toon Enough?" border="0"></td>
          </tr>
        </table>
    <!-- END HEADER -->
        </td>
      </tr>
      <tr>
          <td width="154" valign="top" align="center">
          <script type="text/javascript">
          <!--
            flashObj = new FlashObj(
              "/shared/images/flash/leftnav.swf?exitSignUpUrl=./news.php&amp;navXML=./shared/include/xml/nav.xml?v=4b&amp;username=&amp;baseplayurl=./&amp;baseaccounturl=https://account.test.toontown.com/&amp;exitSignUpHbx=leftnav_exitsignup&amp;baseHbx=/toontown/US/PROSPECT/NEWS&amp;memberServicesUrl=MEMBERSERVICES&amp;emailPrefUrl=./unavailableOnTestServer.php&amp;changePwdUrl=./unavailableOnTestServer.php&amp;memberInfoUrl=./unavailableOnTestServer.php&amp;billingInfoUrl=./unavailableOnTestServer.php&amp;", // swf
              "154", //width
              "1050", // height
              "#ffffff", // background
              "", // version
              "tt_nav", // id
              "menu=false"
              );
            flashObj.render();
          -->
          </script>
        </td>

     <td width="14" style="border-left:1px solid #000000;" rowspan="2">&nbsp;</td>
     <td width="434" rowspan="1" valign="top">
<!-- START MIDDLE CONTENT -->

    <script language="JavaScript">
<!--
function toonPopEntry (url){
contestentrypopup=window.open(url,"contestentryform","width=720,height=770,scrollbars=1");
contestentrypopup.focus();
}
function popVid (url) {
  toonVid = window.open (url,'toontown_video','width=460,height=500');
}
function toonPopWinner (querystring) {
var url = './popups/honorable_mention.php?' + querystring;
art=window.open(url,"valentinewinner05","width=460,height=500,scrollbars=0");
art.focus();
}
//-->
</script>


<!-- START MIDDLE CONTENT -->

<table width="434" border="0" cellpadding="0" cellspacing="0">
	<tr><td align="center" colspan="2"><img src="images/TT_awards_title.jpg" width="424" height="67" alt="Awards"></td></tr>
  <tr><td align="center" colspan="2"><img src="images/TT_webby_awards.jpg" width="424" height="222" alt="Awards"></td></tr>
	<tr><td colspan="2" height="10"></td></tr>
	<tr>
    <td colspan="2">      
      <ul>
        <li>2005 WiredKids Safe Gaming Award</li>
        <li>2005 Webby Awards "Webby Worthy Selection"</li>          
        <li>
          2004 Web Marketing Association's Web Award, Outstanding Game<br>
          Website
        </li>
        <li>2004 Game Industry News Family Game of the Year</li>
        <li>2003 MMORPG Game of the Year by Computer Gaming World</li>      
        <li>2003 Webby Awards People's Voice Award, Kid's Category</li>
        <li>2003 Parents' Choice Silver Honor</li>
        <li>2003 Children's Software Review All Star Award</li>              
        <li>Nominated for Academy of Interactive Arts Society 2003 PC Massively Multiplayer/Persistent World Game of the Year Award</li> 
      </ul>      
    </td>
	</tr>  
</table>

<!-- END MIDDLE CONTENT -->


    <!-- END MIDDLE CONTENT -->
        </td>
        <td width="14" style="border-right:1px solid #000000;" rowspan="2">&nbsp;</td>
     <td width="154" rowspan="1" valign="top" align="center">
       <img src="/shared/images/rightnav/tt_tab_toonsworldunite.gif" width="154" height="15" alt="Toons of the World Unite!">
       <br>
       <script type="text/javascript">
       <!--
         flashObj = new FlashObj(
           "/shared/images/flash/topToons.swf?theDate=02092008&amp;topToonURL=/shared/images/dynamic/topToonImages/2008_02_09_small/&amp;imageBaseURL=/shared/images&amp;moreTopToonsURL=./topToons.php&amp;imageFileURL=/dynamic/topToonImages/2008_02_09_small/", // swf
           "154", //width
           "330", // height
           "#ffffff", // background
           "", // version
           "top_toons", // id
           "menu=false"
           );
         flashObj.render();
       -->
       </script>
       <br>
       <img src="/shared/images/castyourvote.gif" width="154" height="65" alt="Cast your VOTE!">
       <br>

       <script type="text/javascript">
       <!--
         flashObj = new FlashObj(
           "/shared/images/flash/poll_small.swf?basePollPath=/shared/www/&amp;pollId=307&amp;alreadyAnswered=false&amp;pollType=undefined", // swf
           "154", //width
           "208", // height
           "#ffffff", // background
           "", // version
           "poll_small", // id
           "menu=false"
           );
         flashObj.render();
       -->
       </script>

       <br>


     </td>

      </tr>
      <tr><td colspan="5"><img src="/shared/images/lines.jpg" width="770" height="12" alt="" border="0"></td></tr>


      <tr><td colspan="5" align="center">

<script language="JavaScript" type="text/javascript">
var legalFooterColor = "#0000FF";
var legalFtrLine1 = "<div style='font-weight: bold;'>Disney's Toontown Online</div>";
var legalFtrOpts = ["Member/Guest Services","./unavailableOnTestServer.php","Help","./faq.php","Contact Us","http://apps.disneyblast.go.com/cgi-bin/mail/generic_mail.cgi?template=toontown/toonhelp.tpl"]
var legalFtrCpyRgt = '<div style="font: verdana, arial, helvetica, sans-serif 1pt; font-color:#000000;"><a href="./memberAgreement.php">Member Agreements</a>&nbsp;|&nbsp;<a href="http://disney.go.com/guestservices/netiquette.html">House Rules</a><br>&copy; Disney. All rights reserved.';
</script>

<p/>
<div id="tt_footer" align="center">

<script language="JavaScript" src="http://disney.go.com/globalmedia/legal_footer/legalfooter.js" type="text/javascript"></script>

<p/>
</div>
      </td></tr>
    </table>
</body>
</html>