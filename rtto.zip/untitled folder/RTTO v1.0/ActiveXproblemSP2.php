<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<script language="javascript" type="text/javascript">
// promo disabled
var APPopupFlag = 0;
function disableAPPopup() {
}
function LaunchAPPopup() {
}
</script>
<title>Problem Downloading Toontown Installer</title>
<meta name="robots" content="follow,noindex">
<meta http-equiv="imagetoolbar" content="no">
    <!--WEBSIDESTORY CODE HBX(Global)(Universal)-->
    <!--COPYRIGHT 1997-2004 WEBSIDESTORY,INC. ALL RIGHTS RESERVED. U.S.PATENT No. 6,393,479B1. MORE INFO:http://websidestory.com/privacy-->
    <script src = "http://hb.disney.go.com/stat/hitboxcode.js" type="text/javascript"></script>
      <script type="text/javascript">
      hitbox = new HB_CreateObject("/toontown/US/PROSPECT/HELP");
      hitbox.HB_PlaceAccount("DM53030620EW42EN3","DM510612FMNS38EN3","DM51030813MR38EN3","DM5103083LCA38EN3");
      hitbox.HB_PlaceName("_ActiveXproblemSP2");
    
            
    </script>
   
      

      <script type="text/javascript"> 
        hitbox.HB_render();
      </script>       
    
    <!--END WEBSIDESTORY CODE-->
      <script type="text/javascript">
    <!--
        
    
    
    var logs=new Array();
    var logsi=0;

    function logit()
    {
        
        var a ="";

        for (var i=0; i<arguments.length; i++) {
          if (i%2 == 0) {
            // Name
            a+=escape(arguments[i]);
            a+= "=";
          } else {
            // Value
            a+=escape(arguments[i]);
            a+=((i+1)!=arguments.length)?"&":"";
          }

        }

      var s="./shared/www/collect.php?deployment=US&rand="+Math.random()+"&"+a;
      var lognum = ++logsi;
      logs[lognum%9]=new Image();
      logs[lognum%9].src=s;
    }
        //-->
    </script>

  <script type="text/javascript">
<!--

function popWin (name) {

  logit("NAME", "CLICKTHRU-POPUP", "t", name);
  
  if (name == "WHATISGAMECARD") {
    window.open("./popups/gameCardWhatIsMain.php","whatisgamecard","width=700,height=450,resizable=0");
  } else if (name == "GAMECARDHELP") {
    window.open("./popups/gameCardHelpFrameset.html","gamecardhelp","width=518,height=420,resizable=1");
  } else if (name == "WHATISCOGBUCKS") {
    window.open("./popups/cogBucksWhatIsMain.php","whatiscogbucks","width=700,height=450,resizable=0");
  } else if (name == "WHATISGUESTPASS") {
    window.open("./popups/guestPassWhatIsMain.php","whatisguestpass","width=700,height=450,resizable=0");
  } else if (name == "WHATISSONYCDROM") {
    window.open("./popups/sonyCDWhatIsMain.php","whatissonycdrom","width=710,height=450,resizable=0");
  } else if (name == "FINDGAMECARD") {
    window.open("http://www.usa.att.com/webcents/disneystoontown_home.jsp","findgamecard","resizable=1,scrollbars=1,menubar=1,toolbar=1,location=1,status=1,directories=1");
  }


}

function popNews(url) {
  _news_popup = window.open("/frontPageArticle.php?articleID=" + url, "news","width=470,height=400,resizable=0,scrollbars=1");
  _news_popup.focus();
}

//-->
</script>

  <!--Detection Version 2.1.0-->
<script src = "http://disney.go.com/detect/scripts/master_flash_writer.js" type="text/javascript"></script>
<!--End Detection-->
    <script type="text/javascript">

                headerPromoRight_Reg = new Image();
        headerPromoRight_Reg.src = "/shared/images/topnav/hdrPromoRight_reg.gif";

        headerPromoRight_Over = new Image();
        headerPromoRight_Over.src = "/shared/images/topnav/hdrPromoRight_over.gif";

        headerSubscribeRight_Reg = new Image();
        headerSubscribeRight_Reg.src = "/shared/images/topnav/hdrSubscribeRight_reg.gif";

        headerSubscribeRight_Over = new Image();
        headerSubscribeRight_Over.src = "/shared/images/topnav/hdrSubscribeRight_over.gif";

        headerTrialRight_Reg = new Image();
        headerTrialRight_Reg.src = "/shared/images/topnav/hdrFreeTrial_reg.gif";

        headerTrialRight_Over = new Image();
        headerTrialRight_Over.src = "/shared/images/topnav/hdrFreeTrial_over.gif";

        headerDownloadRight_Reg = new Image();
        headerDownloadRight_Reg.src = "/shared/images/topnav/hdrDownloadRight_reg.gif";

        headerDownloadRight_Over = new Image();
        headerDownloadRight_Over.src = "/shared/images/topnav/hdrDownloadRight_over.gif";


        function img_over(imgName) {
          imgOn = eval(imgName + "_Over.src");
          document [imgName].src = imgOn;
        }

        function img_reg(imgName) {
          imgOn = eval(imgName + "_Reg.src");
          document [imgName].src = imgOn;
        }


    </script>

    </head>
<body id='us' onload="javascript:window_onload(); " onunload="if(APPopupFlag){LaunchAPPopup();} "  bgcolor="#ff6633" style="margin-top:0;margin-bottom:0;" >

    <table width="770" cellspacing="0" cellpadding="0" border="0" align="center">
      <tr bgcolor="#FFAA88" height="50">
        <td colspan="2"><font face="arial,helvetica" size="3"><center><b>This is the Toontown Test Server.</b><br>
        If you are here by mistake, please <A href="http://play.toontown.com/">Play Toontown Here</a> instead.</font></td>
      </tr>
    </table>


    


  
    <table width="770" cellspacing="0" cellpadding="0" border="0" bgcolor="#ffffff" align="center">
      <tr>

          <td colspan="5">
    <!-- START HEADER -->
        <table cellspacing="0" cellpadding="0" border="0" align="center">
          <tr>
            <td><a href='./store/index.php'><img src="/shared/images/topnav/customTshirtPromo.gif" width="133" height="109" alt="Custom T-Shirt Promo" border="0"></a><br></td>
                      <td><a href="./news.php"><img src="/shared/images/topnav/hdrCenterLogo.gif" width="516" height="109" alt="Disney's Toontown Online" border="0"></a></td>

                          <td><a href="https://account.test.toontown.com/webWelcome.php"><img name="headerTrialRight" src="/shared/images/topnav/hdrFreeTrial_reg.gif" width="121" height="109" alt="Free Trial!" border="0" onMouseover = "img_over('headerTrialRight');" onMouseout = "img_reg('headerTrialRight');"></a></td>

            
          
          </tr>
          <tr>
            <td colspan="3"><img src="/shared/images/topnav/hdrSepStrip.gif" width="770" height="23" alt="Are You Toon Enough?" border="0"></td>
          </tr>
        </table>
    <!-- END HEADER -->
        </td>
      </tr>
      <tr>
          <td width="154" valign="top" align="center">
          <script type="text/javascript">
          <!--
            flashObj = new FlashObj(
              "/shared/images/flash/leftnav.swf?exitSignUpUrl=./news.php&amp;navXML=./shared/include/xml/nav.xml?v=4b&amp;username=&amp;baseplayurl=./&amp;baseaccounturl=https://account.test.toontown.com/&amp;exitSignUpHbx=leftnav_exitsignup&amp;baseHbx=/toontown/US/PROSPECT/HELP&amp;memberServicesUrl=MEMBERSERVICES&amp;emailPrefUrl=./unavailableOnTestServer.php&amp;changePwdUrl=./unavailableOnTestServer.php&amp;memberInfoUrl=./unavailableOnTestServer.php&amp;billingInfoUrl=./unavailableOnTestServer.php&amp;", // swf
              "154", //width
              "1050", // height
              "#ffffff", // background
              "", // version
              "tt_nav", // id
              "menu=false"
              );
            flashObj.render();
          -->
          </script>
        </td>

     <td width="14" style="border-left:1px solid #000000;" rowspan="2">&nbsp;</td>
     <td width="434" rowspan="1" valign="top">
<!-- START MIDDLE CONTENT -->

    
<SCRIPT LANGUAGE=javascript>
<!--
function window_onload() {
  var agt=navigator.userAgent.toLowerCase();
  var is_winnt = ((agt.indexOf("winnt")!=-1) || (agt.indexOf("windows nt")!=-1));
  if(is_winnt) {
      //NTadminMsg.style.display = "inline";
  }
}
//-->
</SCRIPT>

<table cellspacing="0" cellpadding="0" border="0" width="434">

  <tr height="40" valign="bottom">
    <td align="right"><font face="arial,helvetica" size="1">
    <a href="javascript:window.print();">
    <img src="/shared/images/buttons/print_red.gif" width=" 100" height="23" border="0" alt="Print page">
    </a>
    </font></td>
  </tr>

  <tr height="60">
    <td align="center"><font face="arial,helvetica" size="4" color="#FF0000"><b>Problem installing the latest Toontown update?</b></font></td>
  </tr>

  <tr>
    <td>
    <font face="arial,helvetica" size="2">
    Users of Windows XP with SP2 will need to make a one-time adjustment to some security settings which allow the Toontown ActiveX control to be installed on their computer. <br><br>

    <ul>
      <li> First select Internet Options from the Tools menu from within Internet Explorer. 
      <br><br><li> On the dialog that pops up, click on the Security Tab. 
      <br><br><li> On the Security Tab there are several icons that correspond to various zones - a zone is a level of trust that Internet Explorer places on a website.
      <br><br><li> Click on the icon labeled Internet. 
      <br><br><li> With Internet selected, click on the button labeled Custom Level to configure your computer for Toontown.
      <br><br><li> Find the option for Automatic Prompting for ActiveX Controls and click on the radio button labeled Enable.
      <br><br><li> Find the option for Download Signed ActiveX Controls and click on the radio button labeled Enable.
      <br><br><li> Find the option for Run ActiveX Controls and Plug-Ins and click on the radio button labeled Enable.
      <br><br><li> Find the option for Automatic Prompting for File Downloads and click on the radio button labeled Enable.
      <br><br><li> Click OK to exit the two menus and start Toontown again.
    </ul>

<!--    Internet Explorer should now be configured to prompt you with a yellow bar at the top of your browser window when it wants to install the Toontown ActiveX control.  <br><br>

    <img src="/shared/images/activeX_message2.jpg" width="424" height="123" border="0" alt="example ActiveX information message">
    <br><br>

    <ul>
      <li> When the yellow bar appears, click on it to install the Toontown ActiveX control. <br><br>
    </ul>
-->

    You may also need to configure Internet Explorer to accept cookies from Toontown.  <br><br>

    <ul>
      <li> To adjust your cookie settings open Internet Explorer and select Tools, then Internet Options. <br><br>
      <li> Next click on the Privacy tab, then click on the Sites button. <br><br>
      <li> Enter http://play.toontown.com and click the Allow button. <br><br>
    </ul>

    This will add Toontown to your list of sites you accept cookies from. <br><br>
    
    <br>
    <b><a href="./ActiveXproblem.php" onClick="null;">Click here</a> for more information on installing the Toontown ActiveX control.</b>

    <br><br><br>
    
    </font>
    </td>
  </tr>
</table>


    <!-- END MIDDLE CONTENT -->
        </td>
        <td width="14" style="border-right:1px solid #000000;" rowspan="2">&nbsp;</td>
     <td width="154" rowspan="1" valign="top" align="center">
       <img src="/shared/images/rightnav/tt_tab_toonsworldunite.gif" width="154" height="15" alt="Toons of the World Unite!">
       <br>
       <script type="text/javascript">
       <!--
         flashObj = new FlashObj(
           "/shared/images/flash/topToons.swf?theDate=03142008&amp;topToonURL=/shared/images/dynamic/topToonImages/2008_03_14_small/&amp;imageBaseURL=/shared/images&amp;moreTopToonsURL=./topToons.php&amp;imageFileURL=/dynamic/topToonImages/2008_03_14_small/", // swf
           "154", //width
           "330", // height
           "#ffffff", // background
           "", // version
           "top_toons", // id
           "menu=false"
           );
         flashObj.render();
       -->
       </script>
       <br>
       <img src="/shared/images/castyourvote.gif" width="154" height="65" alt="Cast your VOTE!">
       <br>

       <script type="text/javascript">
       <!--
         flashObj = new FlashObj(
           "/shared/images/flash/poll_small.swf?basePollPath=/shared/www/&amp;pollId=312&amp;alreadyAnswered=false&amp;pollType=undefined", // swf
           "154", //width
           "208", // height
           "#ffffff", // background
           "", // version
           "poll_small", // id
           "menu=false"
           );
         flashObj.render();
       -->
       </script>

       <br>


     </td>

      </tr>
      <tr><td colspan="5"><img src="/shared/images/lines.jpg" width="770" height="12" alt="" border="0"></td></tr>


      <tr><td colspan="5" align="center">

<script language="JavaScript" type="text/javascript">
var legalFooterColor = "#0000FF";
var legalFtrLine1 = "<div style='font-weight: bold;'>Disney's Toontown Online</div>";
var legalFtrOpts = ["Member/Guest Services","./unavailableOnTestServer.php","Help","./faq.php","Contact Us","http://apps.disneyblast.go.com/cgi-bin/mail/generic_mail.cgi?template=toontown/toonhelp.tpl"]
var legalFtrCpyRgt = '<div style="font: verdana, arial, helvetica, sans-serif 1pt; font-color:#000000;"><a href="./memberAgreement.php">Member Agreements</a>&nbsp;|&nbsp;<a href="http://disney.go.com/guestservices/netiquette.html">House Rules</a><br>&copy; Disney. All rights reserved.';
</script>

<p/>
<div id="tt_footer" align="center">

<script language="JavaScript" src="http://disney.go.com/globalmedia/legal_footer/legalfooter.js" type="text/javascript"></script>

<p/>
</div>
      </td></tr>
    </table>
</body>
</html>
