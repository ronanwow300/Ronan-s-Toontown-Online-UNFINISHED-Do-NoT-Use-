<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html><head><title>Backstage</title>
<meta name="robots" content="follow,noindex">
<meta http-equiv="imagetoolbar" content="no">
<link type="text/css" rel="stylesheet" href="./shared/include/css/global.css">
    <script type="text/javascript">
    <!--
        
    
    
    var logs=new Array();
    var logsi=0;

    function logit()
    {
        
        var a ="";

        for (var i=0; i<arguments.length; i++) {
          if (i%2 == 0) {
            // Name
            a+=escape(arguments[i]);
            a+= "=";
          } else {
            // Value
            a+=escape(arguments[i]);
            a+=((i+1)!=arguments.length)?"&":"";
          }

        }

      var s="./shared/www/collect.php?deployment=US&rand="+Math.random()+"&"+a;
      var lognum = ++logsi;
      logs[lognum%9]=new Image();
      logs[lognum%9].src=s;
    }
        //-->
    </script>

  <script type="text/javascript">
<!--

function popWin (name) {

  logit("NAME", "CLICKTHRU-POPUP", "t", name);
  
  if (name == "WHATISGAMECARD") {
    window.open("./popups/gameCardWhatIsMain.php","whatisgamecard","width=700,height=450,resizable=0");
  } else if (name == "GAMECARDHELP") {
    window.open("./popups/gameCardHelpFrameset.html","gamecardhelp","width=518,height=420,resizable=1");
  } else if (name == "WHATISCOGBUCKS") {
    window.open("./popups/cogBucksWhatIsMain.php","whatiscogbucks","width=700,height=450,resizable=0");
  } else if (name == "WHATISGUESTPASS") {
    window.open("./popups/guestPassWhatIsMain.php","whatisguestpass","width=700,height=450,resizable=0");
  } else if (name == "WHATISSONYCDROM") {
    window.open("./popups/sonyCDWhatIsMain.php","whatissonycdrom","width=710,height=450,resizable=0");
  } else if (name == "FINDGAMECARD") {
    window.open("http://www.usa.att.com/webcents/disneystoontown_home.jsp","findgamecard","resizable=1,scrollbars=1,menubar=1,toolbar=1,location=1,status=1,directories=1");
  }


}

function popNews(url) {
  _news_popup = window.open("/frontPageArticle.php?articleID=" + url, "news","width=470,height=400,resizable=0,scrollbars=1");
  _news_popup.focus();
}

//-->
</script>

  <script type="text/javascript" src="http://a.disney.go.com/detect/scripts/master_flash_writer.js"></script>
    <script type="text/javascript">
        <!--
    headerPromoRight_Reg=new Image();
    headerPromoRight_Reg.src="/shared/images/topnav/hdrPromoRight_reg.gif";
    headerPromoRight_Over=new Image();
    headerPromoRight_Over.src="/shared/images/topnav/hdrPromoRight_over.gif";
    headerSubscribeRight_Reg=new Image();
    headerSubscribeRight_Reg.src="/shared/images/topnav/hdrSubscribeRight_reg.gif";
    headerSubscribeRight_Over=new Image();
    headerSubscribeRight_Over.src="/shared/images/topnav/hdrSubscribeRight_over.gif";
    headerTrialRight_Reg=new Image();
    headerTrialRight_Reg.src="/shared/images/topnav/hdrFreeTrial_reg.gif";
    headerTrialRight_Over=new Image();
    headerTrialRight_Over.src="/shared/images/topnav/hdrFreeTrial_over.gif";
    headerDownloadRight_Reg=new Image();
    headerDownloadRight_Reg.src="/shared/images/topnav/hdrDownloadRight_reg.gif";
    headerDownloadRight_Over=new Image();
    headerDownloadRight_Over.src="/shared/images/topnav/hdrDownloadRight_over.gif";

    function img_over(imgName){
      imgOn=eval(imgName + "_Over.src");
      document [imgName].src=imgOn;
    }
    function img_reg(imgName){
      imgOn=eval(imgName + "_Reg.src");
      document [imgName].src=imgOn;
    }
    -->
    </script>
    </head>
<body id='us' onLoad="" onUnload=""  bgcolor="#ff6633" style="margin-top:0;margin-bottom:0;" >

    <table width="770" cellspacing="0" cellpadding="0" border="0" align="center">
      <tr bgcolor="#FFAA88" height="50">
        <td colspan="2"><font face="arial,helvetica" size="3"><center><b>This is the Toontown Test Server.</b><br>
        If you are here by mistake, please <A href="http://play.toontown.com/">Play Toontown Here</a> instead.</font></td>
      </tr>
    </table>


    


  
    <table width="770" cellspacing="0" cellpadding="0" border="0" bgcolor="#ffffff" align="center">
      <tr>
        <td colspan="5">
        <!--Begin Header-->
        <table cellspacing="0" cellpadding="0" border="0" align="center">
          <tr>
            <td><a href='./store/index.php'><img src="/shared/images/topnav/customTshirtPromo.gif" width="133" height="109" alt="Custom T-Shirt Promo" border="0"></a><br></td>
                      <td><a href="./news.php"><img src="/shared/images/topnav/hdrCenterLogo.gif" width="516" height="109" alt="Disney's Toontown Online" border="0"></a></td>

                          <td><a href="https://account.test.toontown.com/webPlay.php"><img name="headerPromoRight" src="/shared/images/topnav/hdrPromoRight_reg.gif" width="121" height="109" alt="Play Now!" border="0" onMouseover="img_over('headerPromoRight');" onMouseout="img_reg('headerPromoRight');"></a></td>

            
          
          </tr>
          <tr>
            <td colspan="3"><img src="/shared/images/topnav/hdrSepStrip.gif" width="770" height="23" alt="Are You Toon Enough?" border="0"></td>
          </tr>
        </table>
        <!--End Header-->
        </td>
      </tr>
      <tr>
          <td width="154" valign="top" align="center">
          <script type="text/javascript">
          <!--
            flashObj=new FlashObj(
              "/shared/images/flash/leftnav.swf?exitSignUpUrl=./news.php&amp;navXML=./shared/include/xml/nav.xml?v=4b&amp;username=&amp;baseplayurl=./&amp;baseaccounturl=https://account.test.toontown.com/&amp;exitSignUpHbx=leftnav_exitsignup&amp;baseHbx=&amp;memberServicesUrl=MEMBERSERVICES&amp;emailPrefUrl=./unavailableOnTestServer.php&amp;changePwdUrl=./unavailableOnTestServer.php&amp;memberInfoUrl=./unavailableOnTestServer.php&amp;billingInfoUrl=./unavailableOnTestServer.php&amp;", // swf
              "154", //width
              "1050", // height
              "#ffffff", // background
              "", // version
              "tt_nav", // id
              "menu=false"
              );
            flashObj.render();
          -->
          </script>
        </td>

     <td width="14" style="border-left:1px solid #000000;" rowspan="2">&nbsp;</td>
     <td width="434" rowspan="1" valign="top">
     <!--End Mid Content-->

<!-- START MIDDLE CONTENT -->
<table cellspacing="0" cellpadding="0" border="0" width="434">
  <tr>
    <td class="bold">BACKSTAGE</td>
    <td align="right" class="bold">1 of <a href="backStage_2_2.php">2</a></td>
  </tr>
  <tr>
    <td colspan="2" class="txtSmall">Issue 2, April 30, 2003</td>
  </tr>
  <tr>
    <td colspan="2" align="center"><br><img src="/shared/images/toonestates.gif" width="333" height="73" alt="" border="0"><br><br></td>
  </tr>
  <tr>
    <td align="center" valign="top">
      <!-- START COLUMN 1 -->
      <table width="200" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td align="center">
            <p align="justify">
              This issue provides a sneak peek into the Toon housing and estates. We are still in the conceptual stages, so designs and functionality will probably change as this project evolves, but we want to give the players and fans the inside scoop on what's coming next. A word to the wise: start saving those jelly beans!<br><br>
                      
              <img src="/shared/images/homeImage.jpg" width="200" height="159" alt="" border="0"><br><br>
              
              Toon Estates Current Design
              <br><img src="/shared/images/divider.gif" width="200" height="1" alt="" border="0"><br>
              Each Toontown account will have an estate - this is where the individual Toon houses for that account will live. The estates will be huge, and in the future, we'll make them expandable. The houses themselves will be small but will also have the ability to be upgraded and expanded in the future.
          </td>
        </tr>
      </table>
      <!-- START COLUMN 1 -->
    </td>
    <td align="center" valign="top">
      <!-- START COLUMN 2 -->
      <table width="200" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td align="center">
            <p align="justify">
              There will be a whole slew of things to do in your new home - you'll be able to play new games, stash your jelly beans in a private bank, use your jelly bean collection to purchase goodies for your humble abode, and keep a wardrobe of fashionable Toony clothes in your closet. More importantly, it's a safe haven, like the playground, where you can heal and rest-up after difficult battles. No COGS allowed here!
              <br><br>
              <img src="/shared/images/jellybeansImage.jpg" width="200" height="167" alt="" border="0">
              <br><br><br>
              <div align="center"><a href="backStage_2_2.php"><img src="/shared/images/nextButton.jpg" width="92" height="25" alt="" border="0"></a></div>
          </td>
        </tr>
      </table>
      <!-- END COLUMN 2 -->
    </td>
  </tr>
  <tr>
    <td colspan="2" align="center"><br><a href="./newsArchive.php">Look at past issues</a></td>
  </tr>
</table>
<!-- END MIDDLE CONTENT -->


    <!--End Mid Content-->
        </td>
        <td width="14" style="border-right:1px solid #000000;" rowspan="2">&nbsp;</td>
     <td width="154" rowspan="1" valign="top" align="center">
       <img src="/shared/images/rightnav/tt_tab_toonsworldunite.gif" width="154" height="15" alt="Toons of the World Unite!">
       <br>
       <script type="text/javascript">
       <!--
         flashObj=new FlashObj(
           "/shared/images/flash/topToons.swf?theDate=05062009&amp;topToonURL=/shared/images/dynamic/topToonImages/2009_05_06_small/&amp;imageBaseURL=/shared/images&amp;moreTopToonsURL=./topToons.php&amp;imageFileURL=/dynamic/topToonImages/2009_05_06_small/", // swf
           "154", //width
           "330", // height
           "#ffffff", // background
           "", // version
           "top_toons", // id
           "menu=false"
           );
         flashObj.render();
       -->
       </script>
       <br>
       <img src="/shared/images/castyourvote.gif" width="154" height="65" alt="Cast your VOTE!">
       <br>
       <script type="text/javascript">
       <!--
         flashObj=new FlashObj(
           "/shared/images/flash/poll_small.swf?basePollPath=/shared/www/&amp;pollId=372&amp;alreadyAnswered=false&amp;pollType=undefined", // swf
           "154", //width
           "208", // height
           "#ffffff", // background
           "", // version
           "poll_small", // id
           "menu=false"
           );
         flashObj.render();
       -->
       </script>
       <br>

      </td>
    </tr>
    <tr><td colspan="5"><img src="/shared/images/lines.jpg" width="770" height="12" alt="" border="0"></td></tr>
      <tr><td colspan="5" align="center">

<script type="text/javascript">
<!--
var legalFooterColor="#0000ff";
var legalFtrLine1="<div style='font-weight: bold;'>Disney's Toontown Online</div>";
var legalFtrOpts=["Member/Guest Services","./unavailableOnTestServer.php","Help","./faq/","Contact Us","http://apps.disneyblast.go.com/cgi-bin/mail/generic_mail.cgi?template=toontown/toonhelp.tpl"]
var legalFtrCpyRgt='<div style="font: verdana, arial, helvetica, sans-serif 1pt; color:#000000;"><a href="./memberAgreement.php">Member Agreements</a>&nbsp;|&nbsp;<a href="http://home.disney.go.com/guestservices/netiquette">House Rules</a><br>&copy; Disney. All rights reserved.</div>';
-->
</script>
<div id="tt_footer" align="center">
  <script type="text/javascript" src="http://a.disney.go.com/globalmedia/legal_footer/legalfooter.js"></script>
</div>
      </td></tr>
    </table>
  <!-- BEGIN DOL Web Analytics 1.0 -->
  <script type="text/javascript" src="http://aglobal.go.com/stat/dolWebAnalytics.js"></script>
  <script type="text/javascript">
    <!--
    cto=new CTO();
    cto.h.mlc='/Toontown/US/Beta/PROSPECT/';
    cto.h.pageName='_backStage_2_1';
    cto.registrationStatus='prospect';
    cto.genre='us';//country
    cto.account='toontown';
    cto.category='dgame';
    cto.site='tnt_beta';
    cto.siteSection='website';
    cto.pageName='backstage_2_1';
    cto.contentType='regular';
    cto.property='tnt';
    cto.track();
    -->
  </script>
  <!-- END DOL Web Analytics 1.0 -->
</body></html>
